# Panduan Akses PC Kantor

Proyek ini akan diinstal di PC Kantor dengan konfigurasi akses sebagai berikut:

## Metode Akses SSH
Untuk mengakses PC kantor via SSH, Anda dapat menggunakan username `pma` melalui dua jalur berikut:

1. **Jalur Tailscale (Remote/VPN)**
   - IP Address: `100.87.103.6`
   - Perintah SSH: `ssh pma@100.87.103.6`

2. **Jalur Lokal (Satu Jaringan Kantor)**
   - IP Address: `192.168.30.188`
   - Perintah SSH: `ssh pma@192.168.30.188`
