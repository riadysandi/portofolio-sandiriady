# 🐳 Sandi Riady Portfolio CV - Docker & Local Deployment Guide

[English](#english) | [Bahasa Indonesia](#bahasa-indonesia)

---

## Bahasa Indonesia

Panduan ini berisi instruksi lengkap untuk menjalankan website portofolio interaktif **Sandi Riady** di komputer lokal Anda menggunakan Docker, serta cara mengunduhnya atau memasukkannya ke GitHub.

### 📥 1. Cara Ekspor Kode (ZIP / GitHub)
Di platform Google AI Studio:
1. Buka **Settings Menu** (Ikon roda gigi/gerigi) di pojok kiri bawah atau kanan atas layar AI Studio Anda.
2. Pilih opsi **Export to GitHub** untuk langsung memasukkan repositori ini ke akun GitHub Anda, ATAU
3. Pilih **Download ZIP** untuk mengunduh seluruh file proyek ini langsung ke komputer lokal Anda sebagai file kompresi ZIP. Ekstrak file tersebut ke dalam folder pilihan Anda.

---

### 🚀 2. Cara Menjalankan Menggunakan Docker
Pastikan Anda sudah menginstal **Docker** dan **Docker Compose** di PC/komputer Anda.

#### Langkah A: Menggunakan Docker Compose (Sangat Direkomendasikan)
1. Buka Terminal atau Command Prompt (CMD) di dalam folder proyek hasil ekstraksi.
2. Jalankan perintah berikut untuk membuat image dan menghidupkan container secara otomatis:
   ```bash
   docker compose up -d --build
   ```
3. Buka browser Anda dan akses:
   ```
   http://localhost:3000
   ```

#### Langkah B: Menggunakan Docker CLI Standar
Jika Anda tidak ingin menggunakan Docker Compose, Anda bisa membuat image dan menjalankan container secara manual:
1. **Build Docker Image**:
   ```bash
   docker build -t sandi-portfolio .
   ```
2. **Run Docker Container**:
   ```bash
   docker run -d -p 3000:3000 --name sandi-portfolio-app sandi-portfolio
   ```
3. Buka browser Anda dan akses:
   ```
   http://localhost:3000
   ```

---

### 🧹 3. Cara Menghentikan Container
* Jika menggunakan Docker Compose:
  ```bash
  docker compose down
  ```
* Jika menggunakan Docker CLI Standar:
  ```bash
  docker stop sandi-portfolio-app && docker rm sandi-portfolio-app
  ```

---

## English

This guide provides instructions on how to run **Sandi Riady's** interactive portfolio website locally on your computer using Docker, as well as how to export it as a ZIP or push it to GitHub.

### 📥 1. How to Export the Code (ZIP / GitHub)
From the Google AI Studio platform:
1. Open the **Settings Menu** (Gear icon) on your AI Studio workspace interface.
2. Select **Export to GitHub** to push this repository directly to your GitHub profile, OR
3. Select **Download ZIP** to download the complete codebase as a ZIP archive. Extract the contents into a folder of your choice.

---

### 🚀 2. How to Run Using Docker
Ensure you have **Docker** and **Docker Compose** installed on your machine.

#### Option A: Using Docker Compose (Recommended)
1. Open your Terminal or Command Prompt (CMD) inside the extracted project directory.
2. Run the following command to automatically build the production image and start the container in detached mode:
   ```bash
   docker compose up -d --build
   ```
3. Open your browser and navigate to:
   ```
   http://localhost:3000
   ```

#### Option B: Using Standard Docker CLI
If you prefer not to use Docker Compose, you can build and run the container manually:
1. **Build the Docker Image**:
   ```bash
   docker build -t sandi-portfolio .
   ```
2. **Run the Docker Container**:
   ```bash
   docker run -d -p 3000:3000 --name sandi-portfolio-app sandi-portfolio
   ```
3. Open your browser and navigate to:
   ```
   http://localhost:3000
   ```

---

### 🧹 3. How to Stop the Container
* If using Docker Compose:
  ```bash
  docker compose down
  ```
* If using Standard Docker CLI:
  ```bash
  docker stop sandi-portfolio-app && docker rm sandi-portfolio-app
  ```
