# 🚀 Panduan Penggunaan & Panduan Instalasi Lokal
**Portofolio & CV Interaktif Sandi Riady**

Panduan lengkap ini dibuat khusus dalam Bahasa Indonesia untuk memudahkan Anda mengunduh, menginstal, dan menjalankan aplikasi portofolio ini di PC/komputer lokal Anda, baik menggunakan **Docker** maupun secara manual menggunakan **Node.js**.

---

## 📥 Bagian 1: Cara Mengambil Source Code dari Google AI Studio

Anda memiliki 2 opsi utama untuk memindahkan kode ini ke komputer Anda melalui antarmuka **Google AI Studio**:

### Opsi A: Mengunduh sebagai ZIP (Paling Cepat)
1. Perhatikan bagian pojok kiri bawah atau kanan atas di layar Google AI Studio Anda.
2. Klik ikon **Settings** (Roda Gigi / Gear ⚙️).
3. Pilih opsi **Download ZIP**.
4. Simpan file ZIP tersebut ke PC Anda, lalu ekstrak (unzip) ke dalam folder kosong pilihan Anda (misalnya `D:\sandi-portfolio`).

### Opsi B: Ekspor Langsung ke GitHub (Sangat Direkomendasikan)
1. Klik ikon **Settings** (Roda Gigi / Gear ⚙️) di Google AI Studio.
2. Pilih **Export to GitHub**.
3. Ikuti proses otorisasi akun GitHub Anda.
4. Kode portofolio akan otomatis dibuat menjadi repositori baru yang siap di-clone atau langsung di-deploy di platform cloud seperti Vercel, Netlify, atau VPS Anda.

---

## 🐳 Bagian 2: Cara Instalasi Menggunakan Docker (Rekomendasi Utama)

Kami sudah menyiapkan konfigurasi Docker siap pakai (`Dockerfile`, `docker-compose.yml`, `.dockerignore`, dan `nginx.conf`). Keuntungannya adalah Anda **tidak perlu** menginstal Node.js di PC Anda secara langsung.

### Prasyarat
Pastikan Anda sudah menginstal **Docker Desktop** di komputer Anda. Jika belum, Anda bisa mengunduhnya secara gratis di [docker.com](https://www.docker.com/).

### Langkah-langkah Menjalankan:

#### Cara 1: Menggunakan Docker Compose (Sangat Mudah & Praktis)
1. Buka aplikasi **Terminal** (Mac/Linux) atau **Command Prompt / PowerShell / Git Bash** (Windows).
2. Arahkan terminal ke dalam folder proyek hasil ekstrak tadi:
   ```bash
   cd /path/ke/folder/sandi-portfolio
   ```
3. Jalankan perintah berikut untuk mem-build image dan mengaktifkan container secara otomatis:
   ```bash
   docker compose up -d --build
   ```
4. Selesai! Buka browser Anda dan akses aplikasi di alamat:
   **[http://localhost:3000](http://localhost:3000)**

#### Cara 2: Menggunakan Docker CLI Manual (Alternatif)
Jika Anda ingin membangun dan menjalankan container secara manual satu per satu:
1. **Build Docker Image**:
   ```bash
   docker build -t sandi-portfolio .
   ```
2. **Jalankan Container**:
   ```bash
   docker run -d -p 3000:3000 --name sandi-portfolio-app sandi-portfolio
   ```
3. Akses portofolio Anda di browser:
   **[http://localhost:3000](http://localhost:3000)**

#### Perintah Tambahan Docker yang Berguna:
* **Menghentikan aplikasi**:
  ```bash
  docker compose down
  ```
  *(Atau jika menggunakan cara manual: `docker stop sandi-portfolio-app && docker rm sandi-portfolio-app`)*
* **Melihat status container**:
  ```bash
  docker ps
  ```

---

## 📦 Bagian 3: Cara Instalasi Manual Menggunakan Node.js (Tanpa Docker)

Jika PC Anda tidak memiliki Docker atau Anda ingin melakukan pengembangan/perubahan kode (development) secara langsung di lokal PC, gunakan cara ini.

### Prasyarat
Pastikan Anda sudah menginstal **Node.js** (versi 18 atau 20) di PC Anda. Anda dapat mengunduhnya di [nodejs.org](https://nodejs.org/).

### Langkah-langkah Menjalankan:
1. Buka terminal atau CMD, arahkan ke folder proyek.
2. **Instal seluruh dependensi (library)**:
   ```bash
   npm install
   ```
3. **Jalankan server pengembangan lokal (Development Mode)**:
   ```bash
   npm run dev
   ```
   *Aplikasi akan berjalan secara interaktif. Anda dapat mengaksesnya di terminal link yang muncul (biasanya `http://localhost:3000`). Setiap perubahan kode yang Anda lakukan akan langsung ter-update di browser.*
4. **Membuat file produksi (Build for Production)**:
   ```bash
   npm run build
   ```
   *Perintah ini akan mengkompilasi file TypeScript dan Tailwind CSS menjadi file static HTML, CSS, dan JS super cepat yang diletakkan di dalam folder `/dist`.*
5. **Menjalankan preview hasil build produksi**:
   ```bash
   npm run preview
   ```

---

## 🛠️ Bagian 4: Struktur File Penting untuk Kustomisasi

Agar Anda lebih mudah mengubah data diri, menambah portofolio project, atau mengganti skill Anda di PC lokal, berikut adalah file-file utama yang perlu Anda ketahui:

* 📄 **`src/data.ts`**  
  **Ini adalah file terpenting!** Semua teks, pengalaman kerja, daftar keahlian (skills), riwayat pendidikan, organisasi, proyek, dan terjemahan bahasa (Indonesia & Inggris) tersimpan rapi di file ini. Anda cukup mengubah isi teks di file ini untuk mengganti konten website Anda.
* 🎨 **`src/index.css`**  
  File konfigurasi gaya global, termasuk font pilihan (*Space Grotesk*, *Inter*, *JetBrains Mono*) dan integrasi Tailwind CSS v4.
* 🖥️ **`src/App.tsx`**  
  Komponen utama aplikasi yang menyatukan seluruh bagian website (Navbar, Hero, SkillsGrid, Timelines, ProjectsGallery, ContactForm, dan fungsi Export PDF).
* ⚙️ **`vite.config.ts` & `tsconfig.json`**  
  File konfigurasi build system dan compiler TypeScript yang tidak perlu Anda ubah kecuali Anda ingin menambahkan konfigurasi tingkat lanjut.

---

## 🚀 Mengunggah ke GitHub & Deploy Online

Jika Anda ingin memamerkan website ini ke internet agar bisa diakses oleh HRD atau Klien secara publik:
1. Pastikan kode Anda sudah berada di repositori **GitHub** (bisa menggunakan Opsi B di Bagian 1).
2. Buat akun gratis di **Vercel** ([vercel.com](https://vercel.com/)) atau **Netlify** ([netlify.com](https://netlify.com/)).
3. Hubungkan akun GitHub Anda ke Vercel/Netlify.
4. Pilih repositori portofolio ini, lalu klik **Deploy**. 
5. Vercel/Netlify akan otomatis mendeteksi konfigurasi Vite dan menyebarkannya ke internet secara gratis dengan domain kustom (misal: `sandi-portfolio.vercel.app`).

---
*Selamat menikmati portofolio CV baru Anda yang sangat modern dan canggih! Jika ada pertanyaan atau kendala saat instalasi lokal, silakan periksa kembali apakah port `3000` di PC Anda sedang digunakan oleh aplikasi lain.*
