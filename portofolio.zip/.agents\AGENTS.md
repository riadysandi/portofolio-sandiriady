# Project Rules & Environment Info

## Office PC Access
This project will be installed on the office PC. The SSH access details are:
- **SSH Username:** `pma`
- **Tailscale SSH IP:** `100.87.103.6` (use: `ssh pma@100.87.103.6`)
- **Local Network IP:** `192.168.30.188` (use: `ssh pma@192.168.30.188`)
